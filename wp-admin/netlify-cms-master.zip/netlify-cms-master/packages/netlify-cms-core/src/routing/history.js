import createHistory from 'history/createHashHistory';

let history = createHistory();

export default history;
