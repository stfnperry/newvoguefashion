import styled from '@emotion/styled';

const WidgetPreviewContainer = styled.div`
  margin: 15px 2px;
`;

export default WidgetPreviewContainer;
