import { NetlifyCmsCore as CMS } from 'netlify-cms-core';
import image from 'netlify-cms-editor-component-image';

CMS.registerEditorComponent(image);
