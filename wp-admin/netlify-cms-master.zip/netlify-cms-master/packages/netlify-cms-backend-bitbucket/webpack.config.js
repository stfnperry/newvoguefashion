const { getConfig } = require('../../scripts/webpack.js');

module.exports = getConfig();
