import TestBackend from './implementation';
import AuthenticationPage from './AuthenticationPage';

export const NetlifyCmsBackendTest = {
  TestBackend,
  AuthenticationPage,
};
export { TestBackend, AuthenticationPage };
