---
title: Community

headline: Be a part of building the CMS of the future.
subhead: We’re serious about being community driven, so everyone is welcome to join the [community chat](https://gitter.im/netlify/NetlifyCMS), and to be a part of our bi-weekly planning sessions (details below).
primarycta: "[Register on Eventbrite →](https://www.eventbrite.com/e/netlify-cms-planning-session-bi-weekly-tickets-35794058994)"

upcomingevent:
  hook: The next development planning session is on

howitworks: Every other week we have public development planning sessions. They're web based, last about an hour, and are geared toward contributors and those interested in contributing. Sessions currently take place every other Wednesday, 9am - 10am PT.

howtojoin: |
  **On the web:**

  1. https://bluejeans.com/278173690

  **By phone:**

  1. [+1.408.740.7256](tel:+14087407256) (United States)

      [+1.408.317.9253](tel:+14083179253) (Alternate number)

      (http://bluejeans.com/numbers)

  2. Enter Meeting ID: 278173690
---
